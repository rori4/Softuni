package L03_IterableAndComparable.P08_PetClinic;

public interface Room {
}
