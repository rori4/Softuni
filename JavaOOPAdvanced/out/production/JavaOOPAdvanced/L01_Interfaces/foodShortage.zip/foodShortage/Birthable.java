package foodShortage;

public interface Birthable {
    String getBirthday();
}
