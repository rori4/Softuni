package birthdayCelebrations;

public interface Birthable {
    String getBirthday();
}
