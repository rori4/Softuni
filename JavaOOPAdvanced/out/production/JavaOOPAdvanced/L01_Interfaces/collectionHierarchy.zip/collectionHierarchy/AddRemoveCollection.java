package collectionHierarchy;

public interface AddRemoveCollection<T> extends AddCollection<T> {
    T remove();
}
