package collectionHierarchy;

public interface AddCollection<T> {
    int add(T element);
}
