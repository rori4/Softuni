package collectionHierarchy;

public interface MyList<T> extends AddRemoveCollection<T>{
    int size();
}
