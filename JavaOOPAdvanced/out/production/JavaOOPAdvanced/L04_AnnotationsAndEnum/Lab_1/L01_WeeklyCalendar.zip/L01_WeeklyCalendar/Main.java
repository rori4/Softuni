package L04_AnnotationsAndEnum.Lab_1.L01_WeeklyCalendar;

public class Main {
    public static void main(String[] args) {
        WeeklyCalendar wc = new WeeklyCalendar();
        wc.addEntry("monday","work");
        wc.addEntry("sunday","sleep");
        Iterable<WeeklyEntry> schedule = wc.getWeeklySchedule();
        for (WeeklyEntry weeklyEntry : schedule) {

        }
    }
}
