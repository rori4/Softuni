package L04_AnnotationsAndEnum.P13_CustomAnnotation;

@CustomAnnotation
public class Wepon {

}
