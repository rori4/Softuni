import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        List<Robot> robots = new ArrayList<>();
        List<Citizen> citizens = new ArrayList<>();

        String input = reader.readLine();
        while (!"END".equals(input.toUpperCase())){
            String[] ind = input.split("\\s+");

            if (ind.length==2){
                Robot robot = new Robot(ind[0],ind[1]);
                robots.add(robot);
            } else {
                Citizen citizen = new Citizen(ind[0],Integer.parseInt(ind[1]),ind[2]);
                citizens.add(citizen);
            }
            input = reader.readLine();
        }
        String searchId = reader.readLine();
        for (Citizen citizen : citizens) {
            String id = citizen.getId();
            if (id.endsWith(searchId)){
                System.out.println(citizen.getId());
            }
        }
        for (Robot robot : robots) {
            String id = robot.getId();
            if (id.endsWith(searchId)){
                System.out.println(robot.getId());
            }
        }
    }
}
